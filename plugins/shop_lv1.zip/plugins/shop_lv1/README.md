

## show LV1

the art

* isometric interiors form https://goldenskullart-store.itch.io/2d-isometric-tileset-village-interior
* merchant charater from https://sanderfrenken.github.io/Universal-LPC-Spritesheet-Character-Generator/#?body=Body_color_light&head=Human_male_light


PNGs/ from https://goldenskullart-store.itch.io/2d-isometric-tileset-village-interior